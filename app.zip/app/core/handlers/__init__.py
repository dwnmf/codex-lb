from app.core.handlers.exceptions import add_exception_handlers

__all__ = ["add_exception_handlers"]
